from pathlib import Path
import hashlib,json,re,sys
root=Path(sys.argv[1] if len(sys.argv)>1 else '/app')/'dist'
assets=root/'assets'
checks={root/'index.html':'4c03f02ecd2a406fad7d5f302a5b3f27e7edca3d3b30d70724c639a313d00c14'}
for path,digest in checks.items():
    actual=hashlib.sha256(path.read_bytes()).hexdigest()
    if actual!=digest:raise SystemExit('Baseline mismatch: '+str(path)+' '+actual)
files=list(root.rglob('*.js'))
if len({p.name for p in files})!=len(files):raise SystemExit('Duplicate asset names need explicit mapping.')
mapping={p.name:p.stem+'-quick067.js' for p in files}
for name in ['index-Iy00Ax_Z-plan056.js','index-Iy00Ax_Z-plan060.js']:mapping[name]='index-quick067.js'
for name in ['engine-BghmR0r--plan056.js','engine-BghmR0r--plan060.js']:mapping[name]='engine-quick067.js'
pattern=re.compile('|'.join(re.escape(name) for name in sorted(mapping,key=len,reverse=True)))
def rewrite(text):return pattern.sub(lambda match:mapping[match.group()],text)
skip={'index-Iy00Ax_Z-plan056.js','engine-BghmR0r--plan056.js'}
written=[]
for path in files:
    if path.name in skip:continue
    text=path.read_text()
    if path.name=='index-Iy00Ax_Z-plan060.js':
        unused='import {ProjectEditor as KwendaProjectEditor050} from "./project-editor-050-plan056.js";'
        if text.count(unused)!=1:raise SystemExit('Old editor import changed.')
        text=text.replace(unused,'')
    output=path.with_name(mapping[path.name])
    output.write_text(rewrite(text))
    written.append(output)
index=root/'index.html'
index.write_text(rewrite(index.read_text()))
for path in written:
    text=path.read_text()
    if any(name in text for name in ['index-Iy00Ax_Z-plan056.js','index-Iy00Ax_Z-plan060.js','engine-BghmR0r--plan056.js','engine-BghmR0r--plan060.js']):
        raise SystemExit('Stale application module reference: '+str(path))
print(json.dumps({'modules':len(written),'entry':'assets/index-quick067.js','index_sha256':hashlib.sha256(index.read_bytes()).hexdigest()}))
